"""CLI command for additive existing-project scaffold onboarding."""

from __future__ import annotations

import json
from pathlib import Path

import click

from grain.services.onboard_service import OnboardService


@click.command("onboard")
@click.argument("path", required=False, default=".")
@click.option("--dry-run", is_flag=True, default=False, show_default=True, help="Report intended scaffold actions without writing.")
@click.option(
    "--format",
    "local_fmt",
    type=click.Choice(["text", "json"]),
    default=None,
    help="Output format override for this command.",
)
@click.pass_context
def onboard_cmd(ctx, path: str, dry_run: bool, local_fmt: str | None) -> None:
    """Scaffold Grain directory structure into an existing repository path."""
    repo = ctx.obj.get("repo") if ctx.obj else None
    fmt = local_fmt or (ctx.obj.get("fmt", "text") if ctx.obj else "text")

    if path == "." and repo:
        target = Path(repo).resolve()
    else:
        target = Path(path).resolve()

    if not target.exists() or not target.is_dir():
        raise click.UsageError(f"Onboard path must be an existing directory: {target}")

    manifest = OnboardService(target).scaffold(dry_run=dry_run)

    if fmt == "json":
        click.echo(
            json.dumps(
                {
                    "created": manifest.created,
                    "skipped": manifest.skipped,
                    "root": manifest.root,
                },
                indent=2,
            )
        )
        return

    click.echo("onboard: ok")
    click.echo(f"  root              {manifest.root}")
    if dry_run:
        click.echo("  dry_run           true")
    click.echo("Created:")
    for rel in manifest.created:
        click.echo(f"- {rel}")
    click.echo("Skipped:")
    for rel in manifest.skipped:
        click.echo(f"- {rel}")
