# Forge

Forge is a CLI-first workflow system for structured AI-assisted software development.

It gives you:
- canonical docs as source of truth
- working docs for sequencing and planning
- task packets as the execution unit
- explicit review and close loops
- minimal-context execution instead of broad repo dumping
- more useful work per agent context window by reducing drift, retries, and unnecessary rereads

Forge is not a coding model by itself.
It is the workflow and file system that external agent CLIs operate against.
It exists in part to help agent-CLI users avoid burning through token windows on broad, repetitive, underspecified conversations.

---

## Who It Is For

Forge is for developers and technical operators who:
- use agent CLIs such as Codex or Claude Code
- want inspectable markdown files instead of opaque orchestration
- want scoped task execution, review, and closure
- want less context drift and lower token waste than ad hoc prompting
- regularly hit context or usage limits before useful work is complete

---

## Core Idea

Forge separates work into layers:

- `docs/canonical/`
  - source-of-truth decisions
- `docs/working/`
  - current plan, backlog, questions, proposals, metrics
- `docs/runtime/`
  - execution rules, manifest, context-loading rules, model profiles
- `tasks/`
  - one packet per task
- `prompts/`
  - stable workflow entrypoints for agent CLIs

---

## Adapter Inventory

Forge uses a contract-driven adapter model to tune workflow behavior for different domains.

The workflow loop is the same for every domain. Adapters change context selection, validation hints, and review focus — not workflow law.

### Official Adapters (Supported Today)

- `code_adapter`
  - Python, Rust, backend services, CLI tooling
- `frontend_adapter`
  - TypeScript, JavaScript, React, Storybook, Tauri UI

### Official Adapters (Planned)

- `docs_adapter`
  - Markdown documentation systems, content repositories, knowledge bases
- `spreadsheet_adapter`
  - Excel and spreadsheet workflows

### Custom Adapters

Users may define custom adapter profiles locally for any domain.

Examples of valid custom adapter domains:
- DevOps workflows — VPS provisioning, deployment setup, service configuration
- System administration — reverse-proxy setup, firewall and SSH hardening, backup planning, monitoring
- Local ops — machine-admin repos, dotfile management, workstation automation
- Containerization — Docker/Compose setup, rollback procedures
- Content pipelines — editorial systems, publishing workflows
- Any operational domain expressible through repo artifacts and task packets

Custom adapters follow the same contract as official adapters. Add them to `docs/runtime/adapter_profiles.md` and declare them in the manifest. No plugin system or marketplace is required.

### Future Possibilities

- shareable community adapter profiles
- adapter-aware template sets per domain

If you are managing content with Forge, `docs_adapter` is the natural direction because it fits markdown-first editorial, knowledge-base, and documentation workflows. If you are managing infrastructure or operations work, define a `devops_adapter` or `local_ops_adapter` with the file patterns and validation hints relevant to your domain.

---

## Recursive Build Principle

Forge is intended to be used to build Forge itself, then to build Sentinel on top of it.

That recursive use is deliberate.
It is one of the main ways the product is validated in real work:

- if Forge cannot manage its own build cleanly, its workflow claims are weak
- if Forge reduces token waste, drift, and retries while building itself, that is stronger evidence than a synthetic demo
- if Sentinel can later verify work produced through Forge, the loop becomes: structure the work, execute the work, verify the result

Recursive building is validation, not proof of universal fit.
Forge still needs to work outside its own repo shape and outside its creator's habits.

---

## Installation

Recommended global install method: `uv tool install grain` (once published).

Requirements:
- Python 3.11+
- `uv` (recommended) or `pip`

Global install from package index:

```bash
uv tool install grain
```

Local source install using uv tool (for development/testing):

```bash
uv tool install --from . grain
```

Fallback local editable install:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

Verify:

```bash
grain --version
grain init --help
```

Expected verification output includes:
- `grain, version <x.y.z>`
- `Usage: grain init [OPTIONS]`

This installs the `grain` CLI entrypoint defined in [`pyproject.toml`](/Users/barbaricum/ai-build-toolkit/pyproject.toml).

Install and repo-state behavior:
- once `grain` is installed into your active environment, you can invoke it from any directory
- `grain init` is the entrypoint for folders that are not yet Grain-managed repos
- commands that inspect or mutate Grain workflow state expect the current folder (or `--repo` target) to contain Grain docs/runtime files already

If you are using an agent CLI, install Grain first, then run the onboarding/start prompts from `prompts/`.

### Troubleshooting

If `grain` is not found after `uv tool install`:
- run `uv tool dir --bin` and add that directory to your `PATH`
- macOS/Linux example:
  - `export PATH="$(uv tool dir --bin):$PATH"`
- Windows PowerShell example:
  - `$env:Path = "$(uv tool dir --bin);$env:Path"`

If you have a Python-version mismatch:
- check local Python: `python --version`
- Grain requires Python `3.11+`
- for uv installs, use a matching interpreter:
  - `uv tool install --python 3.11 grain`

If venv conflicts cause unexpected behavior:
- make sure `which grain` (or `where grain` on Windows) points to the intended tool path
- if needed, remove and reinstall:
  - `uv tool uninstall grain`
  - `uv tool install grain`
- for local source install tests, prefer isolated env vars:
  - `UV_TOOL_DIR`, `UV_CACHE_DIR`, and `HOME` pointed at temp directories

---

## Should You Use Forge For Your Machine?

Yes, sometimes.

Good use cases:
- managing dotfiles or local automation as a project
- maintaining workstation setup scripts
- organizing home-lab, local tooling, or machine-admin workflows
- managing content repositories, docs sites, and markdown-first knowledge bases
- treating your local environment as an inspectable system with tasks, review, and change history

Bad default:
- treating your entire home directory or whole machine as one Forge project

Better pattern:
- create a dedicated repo such as:
  - `local-ops`
  - `machine-admin`
  - `personal-systems`
- use Forge inside that repo

Reason:
- keeps scope bounded
- keeps context smaller
- keeps tasks coherent
- avoids mixing unrelated files and projects into one authority tree

---

## How New Users Should Start

Use the `README` as the entrypoint and the prompts as the workflow engine.

There are two starting modes:

1. new project
2. existing project

### New Project

1. create or enter the project repo
2. run `forge init`
3. open [`prompts/workflow.onboard.new.md`](/Users/barbaricum/ai-build-toolkit/prompts/workflow.onboard.new.md)
4. fill in the `Project Context`
5. paste that prompt into your agent CLI
6. let the agent generate the initial docs, manifest, backlog, and open questions
7. review those generated docs before treating canonical content as approved

Optional onboarding-aware init flags:

```bash
forge init --primary-adapter code_adapter --secondary-adapter frontend_adapter --bootstrap
```

- `--primary-adapter` sets the default adapter context for onboarding.
- `--secondary-adapter` can be repeated for additional adapters.
- `--bootstrap` creates a starter task packet and initializes `docs/working/current_task.md`.

Compatibility note:
- [`prompts/workflow.init.md`](/Users/barbaricum/ai-build-toolkit/prompts/workflow.init.md) is kept as an alias for users who still invoke the old onboarding name.

After onboarding, use the normal loop:

1. `prompts/task.plan.next.md` only when a task must be selected or split
2. `prompts/task.execute.md`
3. `prompts/task.review.md`
4. `prompts/task.close.md`

### Existing Project

The full adoption flow is planned but not fully productized yet.

Current practical path:

1. run `forge init` inside the existing repo
2. use [`prompts/workflow.init.md`](/Users/barbaricum/ai-build-toolkit/prompts/workflow.init.md) as a temporary onboarding starter, but describe the project as an existing system
3. review generated docs carefully
4. treat generated canonical docs as draft until confirmed

Planned dedicated path:
- FR-013 (Existing Project Adoption) — deferred until new-project onboarding is stable; entry criteria recorded in `docs/working/v2_onboarding.md §10`

---

## Agent CLI Usage

Forge is designed to be used from an agent CLI.

The basic pattern is:

1. run the Forge CLI when filesystem scaffolding or validation is needed
2. run a prompt from `prompts/`
3. let the agent update the repo files
4. continue through the structured loop

### Recommended Stable Prompt Surface

Phase planning:
- [`prompts/phase.plan.next.md`](/Users/barbaricum/ai-build-toolkit/prompts/phase.plan.next.md)
- [`prompts/phase.replan.md`](/Users/barbaricum/ai-build-toolkit/prompts/phase.replan.md)
- [`prompts/phase.review.md`](/Users/barbaricum/ai-build-toolkit/prompts/phase.review.md)
- [`prompts/phase.review_and_close.md`](/Users/barbaricum/ai-build-toolkit/prompts/phase.review_and_close.md)

Task planning and execution:
- [`prompts/task.plan.next.md`](/Users/barbaricum/ai-build-toolkit/prompts/task.plan.next.md)
- [`prompts/task.execute.md`](/Users/barbaricum/ai-build-toolkit/prompts/task.execute.md)
- [`prompts/task.review.md`](/Users/barbaricum/ai-build-toolkit/prompts/task.review.md)
- [`prompts/task.close.md`](/Users/barbaricum/ai-build-toolkit/prompts/task.close.md)

Project bootstrap:
- [`prompts/workflow.onboard.new.md`](/Users/barbaricum/ai-build-toolkit/prompts/workflow.onboard.new.md)
- [`prompts/workflow.init.md`](/Users/barbaricum/ai-build-toolkit/prompts/workflow.init.md) (compatibility alias)

### Recommended Daily Loop

Use this loop continuously inside the active phase:

1. `task.plan.next`
   - only when the next task must be selected, split, or added
2. `task.execute`
3. `task.review`
4. `task.close`

Do not run `task.plan.next` every time if a ready task already exists.

### Recommended Planning Loop

Use this less often:

1. `phase.plan.next`
2. `phase.replan` only when the phase shape is wrong
3. `phase.review` or `phase.review_and_close` at phase boundaries

---

## Customization

Forge is meant to be customized to the project it is managing.

Users should customize:
- canonical docs for the project domain and scope
- working docs for sequencing, backlog, and open questions
- adapter selection and adapter profiles
- model strategy and agent preferences
- onboarding outputs for new or existing projects

Users should try to keep stable:
- the core workflow loop
  - plan
  - execute
  - review
  - close
- file-backed workflow state
- authority boundaries between canonical, working, runtime, and task layers
- explicit review and change-proposal gates

Good customization:
- adapt Forge to Python, Rust, React, docs, spreadsheets, local-ops, or mixed projects
- add project-specific constraints, risks, adapters, and backlog structure

Bad customization:
- silently bypass review
- hide state outside the repo
- collapse canonical and working docs into one layer
- make every project invent its own incompatible workflow loop

In short:
- customize the project model
- keep the workflow model disciplined

---

## Minimal CLI Flow

Common commands:

```bash
forge init
forge docs validate
forge task create --title "..."
forge task list
forge task show --id TASK-####
forge task close --id TASK-####
```

In normal Forge usage, the prompts drive most of the workflow and the CLI handles scaffolding, validation, and command surfaces.

---

## Important Rules

- do not treat prompts as canonical truth
- do not edit canonical docs silently
- do not execute multiple unrelated tasks in one packet
- do not let review and close perform backlog planning implicitly
- if prompt or workflow-contract docs change mid-conversation, restart the relevant agent conversation

See:
- [`docs/runtime/PROJECT_RULES.md`](/Users/barbaricum/ai-build-toolkit/docs/runtime/PROJECT_RULES.md)
- [`docs/runtime/docs_manifest.yaml`](/Users/barbaricum/ai-build-toolkit/docs/runtime/docs_manifest.yaml)

---

## Current Product State

Current repo status:
- v1 core workflow is complete (Phases 1–5 closed)
- v2 Phase 6 (Adapter System Foundation) closed
- v2 Phase 7 (New-Project Onboarding Flow) complete — `forge init` supports adapter selection and starter-packet bootstrap
- v2 Phase 8 (Workflow Automation Runner Foundation) active — planning and CLI-first runner primitives
- existing-project adoption remains deferred behind FR-013 entry criteria

See:
- [`docs/working/current_focus.md`](/Users/barbaricum/ai-build-toolkit/docs/working/current_focus.md)
- [`docs/working/implementation_plan.md`](/Users/barbaricum/ai-build-toolkit/docs/working/implementation_plan.md)
- [`docs/working/v2_onboarding.md`](/Users/barbaricum/ai-build-toolkit/docs/working/v2_onboarding.md)

---

## Short Recommendation

For future users, the intended startup experience should be:

1. read this `README`
2. choose:
   - new project
   - existing project
3. run `forge init`
4. run the onboarding prompt in an agent CLI
5. move into the standard task loop

That is the cleanest human entrypoint without overloading the `README` itself with the entire onboarding conversation.
